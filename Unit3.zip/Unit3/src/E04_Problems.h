//
//  E04_Problems.h
//  Unit02_Exercise04_Understanding_Optimization
//

#ifndef E04_Problems_h
#define E04_Problems_h

#include <stdio.h>
#include <stdlib.h>

int *getSquareLeaders(int *numbers, int len, int *leadersCount);
int getSteps(int s);

#endif /* E04_Problems_h */





