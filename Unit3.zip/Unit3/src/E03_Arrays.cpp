//
//  E03_Arrays.cpp
//  Unit03_Exercise03_Understanding_Arrays
//

/*
 
 Note:
 Implement the functions in this exercise file to make the tests
 pass in E03_ArraysSpec.cpp file.
 
 */

#include "E03_Arrays.h"




/*
 OVERVIEW:  You are given scores for students of a class in alphabetical order. Write a function that returns the names and scores of top K students.
 Input is array of structures of type student (each student has name and score).
 E.g.: If input is [ { "stud1", 20 }, { "stud2", 30 }, { "stud3", 40 } ] (three students with marks 20, 30 , 40) and K value is 2.
 return top 2 students [ { "stud2", 30 }, { "stud3", 40 } ]
 
 INPUTS: array of structures of type student, length of the array, integer K.
 
 OUTPUT: Return top K students from array. Output need not be in decreasing order of scores.
 
 NOTES:
 Problem Code :TK
 */

void sort(struct student * DataBase,int first,int last)
{
	struct student temp;
	int idx, j, piv;
	{
		piv = first;
		idx = first;
		j = last;
		if (idx < j)
		{
			while (idx < j)
			{
				while ((DataBase[idx].score <= DataBase[piv].score )&& (idx < j))
				{
					idx++;
				}
				while (DataBase[j].score > DataBase[piv].score)
				{
					j--;
				}
				if (idx < j)
				{
					temp = DataBase[idx];
					DataBase[idx] = DataBase[j];
					DataBase[j] = temp;
				}
			}
			temp = DataBase[piv];
			DataBase[piv] = DataBase[j];
			DataBase[j] = temp;
			sort(DataBase, first, j - 1);
			sort(DataBase, j + 1, last);
		}
	}
}
int check(struct student *Database,int size)
{
	for (int idx = 0; idx<size-1; idx++)
	{
		if (Database[idx].score > Database[idx + 1].score)
			return 1;
	}
	return 0;
}
struct student ** topKStudents(struct student *students, int size, int K) {
	struct student **Database = (struct student **)malloc(sizeof(struct student*)*size);
	int idx,pos=0;
	if (K > size)
	{
		for (idx = 0; idx < size; idx++)
		{
			Database[idx] = (struct student*)malloc(sizeof(struct student));
		}
	}
	else
	{
		for (idx = 0; idx < K; idx++)
		{
			Database[idx] = (struct student *)malloc(sizeof(struct student));
		}
	}
	if (size > 1 && check(students,size))
	{
		sort(students,0,size);
	}
	for (idx = size - K; idx < size; idx++)
	{
		Database[pos++][0] = students[idx];
	}
	return Database;
}



/*
 OVERVIEW: You are given a bank statement where transactions are ordered by date. Write a function that finds the number of transactions in that statement after a given date.
 -- find the count of numbers greater than a given number in a sorted array.
 E.g.: Input: A[3] = { { 10, "09-10-2003", "First" }, { 20, "19-10-2004", "Second" }, { 30, "03-03-2005", "Third" } };
 date = "19-10-2004"
 Output: 1 (as there is only one transaction { 30, "03-03-2005", "Third" })
 
 INPUTS: One bank statement (array of transactions) and date.
 
 OUTPUT: Return the number of transactions in that statement after a given date.

 NOTES:
 Problem Code: CGT
 
 */

int Date_format(char *date, int format)
{
	if (format == 0)
	{
		return (date[0] - 48 )* 10 + (date[1] - 48);
	}
	if (format == 1)
	{
		return (date[3] - 48) * 10 + (date[4] - 48);
	}
	if (format == 2)
	{
		return (date[6] - 48) * 1000 + (date[7] - 48) * 100 + (date[8] - 48) * 10 + date[9] - 48;
	}
}
int countGreaterTransactions(struct transaction *transactions, int len, char *date) {
	int count = 0, idx = 0;
	for (idx = 0; idx < len; idx++)
	{
		if (Date_format(transactions[idx].date, 2) > Date_format(date, 2))
			count++;
		if (Date_format(transactions[idx].date, 2) == Date_format(date, 2))
		{
			if (Date_format(transactions[idx].date, 1) > Date_format(date, 1))
				count++;
			else
			{
				if (Date_format(transactions[idx].date, 1) == Date_format(date, 1))
				{
					if (Date_format(transactions[idx].date, 0) > Date_format(date, 0))
						count++;
				}
			}
		}
	}
	return count;
}



/*
 OVERVIEW: You are given 2 bank statements that are ordered by date -
 Write a function that produces a single merged statement ordered by dates.
 E.g.: Input: A[3] = { { 10, "09-10-2003", "First" }, { 20, "19-10-2004", "Second" }, { 30, "03-03-2005", "Third" } };
 B[2] = { { 10, "09-10-2003", "First" }, { 220, "18-01-2010", "Sixth" } };
 Output: { { 10, "09-10-2003", "First" }, { 10, "09-10-2003", "First" }, { 20, "19-10-2004", "Second" },  30, "03-03-2005", "Third" }, { 220, "18-01-2010", "Sixth" } }
 
 INPUTS: Two bank statements (array of transactions).
 
 OUTPUT: Combined statement ordered by transaction date.
 
 NOTES:
 */
int check(char *transactions, char *date)
{
	if (Date_format(transactions, 2) < Date_format(date, 2))
		return 1;
	if (Date_format(transactions, 2) == Date_format(date, 2))
	{
		if (Date_format(transactions, 1) < Date_format(date, 1))
			return 1;
		else
		{
			if (Date_format(transactions, 1) == Date_format(date, 1))
			{
				if (Date_format(transactions, 0) < Date_format(date, 0))
					return 1;
				if (Date_format(transactions, 0) == Date_format(date, 0))
					return -1;
			}
		}
	}
	return 0;
}

struct transaction *mergeSortedTransactions(struct transaction *A, int ALen, struct transaction *B, int BLen) {
	if (A == NULL || B == NULL)
		return NULL;
	struct transaction * new_Database = (struct transaction*)malloc(sizeof(struct transaction)*(ALen + BLen));
	int idx = 0, idx_2 = 0,pos = 0,count = 0;
	while (idx < ALen && idx_2 < BLen)
	{
		if (check(A[idx].date, B[idx_2].date) == -1)
		{
			new_Database[pos++] = A[idx++];
			new_Database[pos++] = B[idx_2++];
		}
		else if (check(A[idx].date, B[idx_2].date))
		{
			new_Database[pos++] = A[idx++];
		}
		else
		{
				new_Database[pos++] = B[idx_2++];
		}
	}
	while (idx < ALen)
	{
		new_Database[pos++] = A[idx++];
	}
	while (idx_2 < BLen)
	{
		new_Database[pos++] = B[idx_2++];
	}
	return new_Database;
}


/*
 OVERVIEW: You are given 2 bank statements that are ordered by date.
 Write a function that returns dates common to both statements
 (ie both statements have transactions in these dates).
 E.g.: Input:
 A[3] = { { 10, "09-10-2003", "First" }, { 20, "19-10-2004", "Second" }, { 30, "03-03-2005", "Third" } };
 B[3] = { { 10, "09-10-2003", "First" }, { 220, "18-01-2010", "Sixth" }, { 320, "27-08-2015", "Seventh" } };
 Output: { { 10, "09-10-2003", "First" } }
 
 INPUTS: Two bank statements (array of transactions).
 
 OUTPUT: Transactions having same dates.
 
 
 ERROR CASES: Return NULL for invalid inputs.
 
 NOTES:
 */

struct transaction *sortedArraysCommonElements(struct transaction *A, int ALen, struct transaction *B, int BLen) {
	if (A==NULL || B ==NULL)
	return NULL;
	struct transaction * new_Database=NULL;
	int pos = 0, idx = 0, idx_2 = 0;
	while (idx < ALen)
	{
		while (idx_2 < BLen)
		{
			if (check(A[idx].date, B[idx_2].date) == -1)
			{
				pos++;
				new_Database = (struct transaction*)realloc(new_Database, sizeof(struct transaction)*pos);
				new_Database[pos - 1] = A[idx];
			}
			idx_2++;
		}
		idx++;
		idx_2 = 0;
	}
	return new_Database;
}
