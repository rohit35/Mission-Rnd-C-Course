//
//  E01_Arrays.h
//  Unit02_Exercise01_Understanding_Arrays
//

#ifndef E01_Arrays_h
#define E01_Arrays_h

int maxPosNegSum(int *numbers, int size);
int removeDuplicates(int *numbers, int size);

#endif /* E01_Arrays_h */

