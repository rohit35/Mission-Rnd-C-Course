/*

Actions:
You need to implement the function stubs in exercise files in src project.
 - E01_Arrays.cpp
 - E02_Arrays.cpp
 - E03_Arrays.cpp
 - E04_Problems.cpp
 
*/



#include <stdlib.h>
#include <stdio.h>

#include "E01_Arrays.h"
#include "E02_Arrays.h"
#include "E03_Arrays.h"
#include "E04_Problems.h"



int main(){
    // Note#1:
    // For testing/debugging a function
    // you can call a function with necessary parameters from here
    // All the necessary header files are included
	
	return 0;
}


