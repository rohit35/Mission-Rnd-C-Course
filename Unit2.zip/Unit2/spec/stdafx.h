// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

// place holders
#define ___ -99  // 3 underscores;  fill in the blank with integer
#define ____ ""  // 4 underscores; fill in the blank with string

// 6 underscores; array of 10 size, fill in the blank with array
#define ______ {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
