//
//  E01_Functions.cpp
//  Unit02_Exercise01_Understanding_Functions
//

/*

Note:
Implement the functions in this exercise file to make the tests
pass in E01_FunctionsSpec.cpp file.

*/

#include "E01_Functions.h"
#include<string.h>

int Inorder(TreeNode*root)
{
	int Total = 0;
	if (root == NULL)
		return 0;
	if (root != NULL)
	{
		Total += Inorder(root->left);
		Total += root->data;
		Total += Inorder(root->right);
	}
	return Total;
}
int sumOfNodes(TreeNode *root) {
	return Inorder(root);
}

int numberOfNodes(TreeNode *root) {
	if (root == NULL)
		return 0;
	int Total = 0;
	if (root != NULL)
	{
		Total += numberOfNodes(root->left);
		Total += 1;
		Total += numberOfNodes(root->right);
	}
	return Total;
}

int numberOfLeafNodes(TreeNode *root) {
	if (root == NULL)
		return 0;
	if (root != NULL)
	{
		if (root->left == NULL && root->right == NULL)
			return 1;
		else
			return numberOfLeafNodes(root->left) + numberOfLeafNodes(root->right);
	}
	return 0;
}


//
// Note: don't change this function code
//
// sort records, based on specific parameters.
//
void sort(struct people *peopleRecords[], int size, IsInOrderPeopleFunc isInOrder) {
	// implement simple sorting method
	int positionToReplace;
	for (int i = 0; i < size - 1; i++) {
		positionToReplace = i;
		for (int j = i + 1; j < size; j++) {
			if (!isInOrder(peopleRecords[positionToReplace], peopleRecords[j])) {
				positionToReplace = j;
			}
		}
		// swap the records in position: i & positionToReplace
		struct people *temp = peopleRecords[i];
		peopleRecords[i] = peopleRecords[positionToReplace];
		peopleRecords[positionToReplace] = temp;
	}
}

//
// write this method to make the sorting by age non-ascending order work
//
// Returns
// 1 - yes non-ascending order
// 0 - otherwise
int isNonAscendingByAge(struct people *record1, struct people *record2) {
	if (record1->age >= record2->age)
		return 1;
	return 0;
}

// Note: don't change this function code
// sort records based on age non-ascending order
void sortByAgeNonAscending(struct people *peopleRecords[], int size) {
	// create isNonAscendingByAge function and call sort method
	sort(peopleRecords, size, isNonAscendingByAge);
}


//
// write this method to make the sorting by name non-decending order work
//
// Returns
// 1 - yes non-decending order
// 0 - otherwise
int isNonDecendingByName(struct people *record1, struct people *record2) {
	// write your code here
	if (strcmp(record1->name, record2->name) == 0)
		return 1;
	int loop = 0;
	int length = strlen(record1->name);
	int compare = strlen(record2->name);
	if (compare < length)
		return 1;
	while (loop < length)
	{
		if (record1->name[loop] <= record2->name[loop])
			loop++;
		else
			return 0;
	}
	return 1;
}

// Note: don't change this function code
// sort records based on name non-decending order
void sortByNameNonDecending(struct people *peopleRecords[], int size) {
	// create isNonDecendingByName function and call sort method
	sort(peopleRecords, size, isNonDecendingByName);
}

int number(int n)
{
	int count = 0;
	if (n == 0)
		return 1;
	while (n != 0)
	{
		count++;
		n /= 10;
	}
	return count;
}
//
// The 'format' will contain only %c and %d, format specifiers
// rest are just characters
//

// Returns
//   number of characters in the output string
//   when printed with format and the two arguments
//
// e.g:
// ("Hai %c 00%d", 'b', 7) => 9
//  since "Hai b 007" contains 9 characters
int outputStringLength(char *format, char ch, int n) {
	int count = 0, idx = 0;
	while (idx != (strlen(format)))
	{
		if (format[idx] == '%' && format[idx + 1] == 'c')
		{
			count++;
			idx += 2;
		}
		else if (format[idx] == '%' && format[idx + 1] == 'd')
		{
			count += number(n);
			idx += 2;
		}
		else
		{
			count++;
			idx++;
		}
	}
	return count;
}