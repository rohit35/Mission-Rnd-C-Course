//
//  E02_Strings.cpp
//  Unit02_Exercise02_Understanding_Strings
//


/*

Note:
Implement the functions in this exercise file to make the tests
pass in E02_StringsSpec.cpp file.
*/
#include<string.h>
#include "E02_Strings.h"

//
// sum of most significant digits of non-negative integers.
//
int sumOfMSDs(char *pNumber1, char *pNumber2) {
	return (pNumber1[0] - 48 + pNumber2[0] - 48);
}
void rev(char *string)
{
	int start = 0, end = strlen(string) - 1;
	char temp;
	while (start < end)
	{
		temp = string[start];
		string[start++] = string[end];
		string[end--] = temp;
	}
}
//
// sum of 2 non-negative numbers
// pNumber1 and pNumber2 are numbers in string format
// e.g:
// "4", "2" => "6"
// "84", "37" => "121"
// "999", "1" => "1000"
//
// 0 < number of digits < 100
//
char *sum(char *pNumber1, char *pNumber2)
{
	int max_length = strlen(pNumber1), min_length = strlen(pNumber2), carry = 0, sum = 0, idx = 0;
	char *result = (char*)malloc(sizeof(char)*(max_length + 1));
	while (idx<min_length)
	{
		sum = pNumber1[max_length - idx - 1] + carry + pNumber2[min_length - idx - 1] - 48;
		if (sum > 57)
		{
			carry = 1;
			sum -= 10;
		}
		else
		{
			carry = 0;
		}
		result[idx++] = sum;
	}
	while (idx<max_length)
	{
		sum = carry + pNumber1[max_length - idx - 1];
		if (sum > 57)
		{
			carry = 1;
			sum -= 10;
		}
		else
		{
			carry = 0;
		}
		result[idx++] = sum;
	}
	if (carry)
		result[idx++] = '1';
	result[idx] = '\0';
	rev(result);
	return result;
}

//
// replicate string n times
//
//e.g:
// "aum ", 3 => "aum aum aum "
// "-integrity-inspire-insight-", 3 => "integrity-inspire-insight--integrity-inspire-insight--integrity-inspire-insight-"
//
char *replicateNTimes(char *mantra, int n) {
	if (mantra == "")
		return mantra;
	char *pointer = (char*)malloc(sizeof(char) * 10000);
	pointer[0] = '\0';
	while (n--)
	{
		strcat(pointer, mantra);
	}
	return pointer;
}

//
// repeat character, position times
//
// e.g:
// "mrd" => "mrrddd"
// "btech" => "btteeecccchhhhh"
//
char *repeatPositionTimes(char *word) {
	if (word == NULL)
		return NULL;
	char *result = (char*)malloc(sizeof(char) * 100000);
	int idx = 0, pos = 0, times = 1;
	while (word[idx] != '\0')
	{
		times = idx + 1;
		while (times--)
		{
			result[pos++] = word[idx];
		}
		idx++;
	}
	result[pos] = '\0';
	return result;
}

//
// scanf integer implementation
//
int scanfInt(char *input) {
	int Total = 0, idx = 0, length = strlen(input);
	while (idx<length)
	{
		Total = Total * 10 + (input[idx] - 48);
		idx++;
	}
	return Total;
}

//
// scanf float implementation
//
float scanfFloat(char *input) {
	float  Total = 0, decimal = 0;
	int loop = 0, idx = 0;
	while (input[idx] != '\0')
	{
		if (loop == 0 && input[idx] != '.')
		{
			Total = Total * 10 + (input[idx++] - 48);
		}
		else
		{
			if (input[idx] == '.')
			{
				loop = 1;
				idx++;
			}
			else
			{
				decimal = decimal * 10 + (input[idx++] - 48);
				loop++;
			}
		}
	}
	idx = 10;
	loop -= 2;
	while (loop--)
	{
		idx *= 10;
	}
	decimal = decimal / idx;
	Total = (Total + decimal);
	return Total;
}

//
// printf implementation
//
// e.g:
// ("%d", 234) => "234"
// ("%3d",  3)  => "  3"
// ("%03d", 7) => "007"
//
void convert(char *str, int num, int spaces, char *extra_num)
{
	int idx = 0;
	if (num == 0)
	{
		str[0] = '0';
		str[1] = '\0';
	}
	else
	{
		while (num != 0)
		{
			str[idx++] = num % 10 + 48;
			num /= 10;
		}
		str[idx] = '\0';

	}
	if (spaces != -1 && extra_num != NULL)
	{
		spaces = spaces - strlen(str);
		while (spaces--)
		{
			strcat(str, extra_num);
		}
	}
	else
	{
		if (spaces != -1)
		{
			extra_num = (char*)malloc(sizeof(char) * 2);
			extra_num[0] = ' ';
			extra_num[1] = '\0';
			spaces = spaces - strlen(str);
			while (spaces--)
			{
				strcat(str, extra_num);
			}
		}
	}
	rev(str);
}
char *printfInt(char *format, int n) {
	char *res = (char*)malloc(sizeof(char) * 15);
	if (format[0] == '%' && format[1] == 'd')
	{
		convert(res, n, -1, NULL);
	}
	else
	{
		if (format[0] == '%' && format[2] == 'd')
		{
			convert(res, n, format[1] - 48, NULL);
		}
		if (format[0] == '%' && format[3] == 'd')
		{
			char *character = (char*)malloc(sizeof(char) * 2);
			character[0] = format[1];
			character[1] = '\0';
			convert(res, n, format[2] - 48, character);
		}
	}
	return res;
}

//
// float format print
// e.g:
// ("%.2f", 2.34455f) => "2.34"
// ("%f",0.123456f) => "0.123456"
char *printfFloat(char *format, float n) {
	int num, value = (int)n;
	float imag = n - value;
	if (format[0] == '%' && format[1] == 'f')
	{
		imag *= 1000000;
	}
	if (format[1] == '.')
	{
		num = format[2] - 48;
		int idx = 1;
		while (num--)
		{
			idx *= 10;
		}
		imag *= idx;
	}
	char *res_1 = (char*)malloc(sizeof(char) * 15);
	char *res_2 = (char*)malloc(sizeof(char) * 6);
	convert(res_1, value, -1, NULL);
	convert(res_2, (int)imag, -1, NULL);
	strcat(res_1, ".");
	strcat(res_1, res_2);
	return res_1;
}

//
// create command line
// Note:
//  - with single space between arguments
//  - no spaces at the end
//
char *getCommandLine(int argc, char *argv[]) {
	char *result = (char*)malloc(sizeof(char) * 10000);
	result[0] = '\0';
	int idx = 0;
	while (idx < argc)
	{
		strcat(result, argv[idx]);
		if ((idx + 1) != argc)
		{
			strcat(result, " ");
		}
		idx++;
	}
	return result;
}

char *getExecutableName(int argc, char *argv[]) {
	return argv[0];
}

//
// remove white spaces in program statement
//
// Note: the characters between double quotes must not change
//
// e.g:
// 'printf (   "compiler first removes unnessary spaces"  )  ;'  =>
// 'printf("compiler first removes unnessary spaces");'
//
void removeSpaces(char *statement) {
	int loop = 1, idx = 0, pos = 0;
	while (statement[idx] != '\0')
	{
		if (loop % 2 == 1 && statement[idx] == ' ')
		{
			idx++;
		}
		else if (statement[idx] == '"')
		{
			loop++;
			statement[pos++] = statement[idx++];
		}
		else
		{
			statement[pos++] = statement[idx++];
		}
	}
	statement[pos] = '\0';
}


// Return
// 1 - if string t is suffix of s.
// 0 - otherwise

// returns 1 if the string t occurs at the end of the string s, and zero otherwise
int strend(char *s, char *t) {
	int len_1 = strlen(s) - 1, len_2 = strlen(t) - 1;
	if (s[len_1] == t[len_2])
	{
		while (len_2 != 0 && s[len_1] == t[len_2])
		{
			len_1--;
			len_2--;
		}
		if (len_2 == 0)
			return 1;
	}
	return 0;
}
