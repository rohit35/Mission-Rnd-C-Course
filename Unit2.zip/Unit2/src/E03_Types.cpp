//
//  E03_Types.cpp
//  Unit02_Exercise03_Understanding_Types
//

#include "E03_Types.h"
#include "L02_Strings.h"
#include<string.h>
//
// Note: The digits in the Base256Number are saved in reverse order.
//

// Note:
// In this file you should not modify 3 functions,
// for which implementation is already given in this file
// The 3 functions are:
// - Base256Number *newNumberInBase256(int n);
// - Base256Number *multiplyInBase256(Base256Number *pNumber1, Base256Number *pNumber2)
// - Base256Number *integerDivisionInBase256(Base256Number *pNumber, Base256Number *pDiv)


//
// creates a new structure for base 256 number
// and initialize with n in base-256
//
// DON'T MODIFY THE CODE OF THIS FUNCTION
//
Base256Number *newNumberInBase256(int n) {
	int base = 256;

	int numberOfDigits = 0;
	int number = n;
	do {
		numberOfDigits++;
		number /= base;
	} while (number > 0);

	Base256Number* base256Number = (Base256Number*)malloc(sizeof(Base256Number));
	base256Number->numberOfDigits = 0;
	base256Number->numberOfDigits = numberOfDigits;
	base256Number->digits = (UInt8*)malloc(numberOfDigits * sizeof(UInt8));

	for (int digitPos = 0; digitPos < numberOfDigits; digitPos++) {
		base256Number->digits[digitPos] = n % base;
		n /= base;
	}

	return base256Number;
}

void reverse(char *string)
{
	int start = 0, end = strlen(string) - 1;
	char temp;
	while (start < end)
	{
		temp = string[start];
		string[start++] = string[end];
		string[end--] = temp;
	}
}
char *int_char(int src)
{
	char r, *string = (char*)malloc(10 * sizeof(char));
	int n = src, j = 0, temp = 0;
	if (src == 0)
	{
		string[0] = '0';
		string[1] = '\0';
		return string;
	}
	if (src<0)
	{
		n = n*-1;
		temp = 1;
	}
	while (n != 0)
	{
		r = n % 10;
		string[j++] = (r + 48);
		n /= 10;
	}
	if (temp == 1)
	{
		string[j++] = 43;
	}
	string[j] = '\0';
	reverse(string);
	return string;
}
char *int_char_base256(int src)
{
	char r, *string = (char*)malloc(10 * sizeof(char));
	int n = src, j = 0;
	if (src == 0)
	{
		string[0] = '0';
		string[1] = '0';
		string[2] = '\0';
		return string;
	}
	while (n != 0)
	{
		r = n % 16;
		if (r > 9)
		{
			string[j++] = (r + 87);
		}
		else
		{
			string[j++] = (r + 48);
		}
		n /= 16;
	}
	string[j++] = '\0';
	if (strlen(string) == 1)
	{
		strcat(string, "0");
		reverse(string);
	}
	else
	{
		reverse(string);
	}
	return string;
}
// Implement the function to
// print the given base 256 number using the format sepcifiers
// %D and %H
//
// For example for 4 digits base 256 number with format specifier
// %D - print digits in the format - 15.0.254.11
// %H - print digits in the format - 0f:00:0a:0b
//
// e.g: like (format, pNumber) => output string
// ("Number (base 256): %D", {4, [11, 254, 0, 15]) => "Number (base 256): 15.0.254.11"
// ("Number (base 256): %H", {4, [11, 254, 0, 15]) => "Number (base 256): 0f:00:fe:0b"
//
// Note: Each digit in base 256 is saved in reverse order
//
char *printBase256Number(char *format, Base256Number *pNumber) {
	char *result = (char*)malloc(sizeof(char) * 100);
	int r_idx = 0, idx = 0, type_format = 0, total = 0;
	while (format[r_idx] != '%')
	{
		result[r_idx] = format[r_idx++];
	}
	idx = r_idx + 2;
	result[r_idx] = '\0';
	if (format[r_idx] == '%' && format[r_idx + 1] == 'H')
	{
		type_format = 1;
	}
	char *point = (char*)malloc(sizeof(char) * 2);
	point[0] = '.';
	point[1] = '\0';
	total = pNumber->numberOfDigits;
	if (type_format == 0)
	{
		while (total--)
		{
			strcat(result, int_char(pNumber->digits[total]));
			if (total != 0)
			{
				strcat(result, point);
			}
		}
	}
	else
	{
		point[0] = ':';
		while (total--)
		{
			strcat(result, int_char_base256(pNumber->digits[total]));
			if (total != 0)
			{
				strcat(result, point);
			}
		}
	}
	r_idx = strlen(result);
	while (format[idx] != '\0')
	{
		result[r_idx] = format[idx++];
		r_idx++;
	}
	result[r_idx] = '\0';
	return result;
	return result;
}

//
// Returns
//  1 - yes
//  0 - no
//
// check if the base 256 number is palindrome or not
//
int isPalindrome(Base256Number *number) {
	int start = 0, end = number->numberOfDigits - 1;
	while (start < end)
	{
		if (number->digits[start] != number->digits[end])
			return 0;
		start++;
		end--;
	}
	return 1;
}

//
// add in base 256
//
// implement the function to add 2 base 256 numbers
//
Base256Number *addInBase256(Base256Number *pNumber1, Base256Number *pNumber2) {
	Base256Number *Database = (Base256Number*)malloc(sizeof(Base256Number) * 1);
	Base256Number *temp;
	Database->numberOfDigits = 0;
	Database->digits = (UInt8*)calloc(1200, sizeof(UInt8));
	int idx_1 = 0, idx_2 = 0, temp_idx = 0, carry = 0;
	while (idx_1 != pNumber1->numberOfDigits && idx_2 != pNumber2->numberOfDigits)
	{
		temp = newNumberInBase256(pNumber1->digits[idx_1] + pNumber2->digits[idx_2] + carry);
		Database->numberOfDigits++;
		Database->digits[Database->numberOfDigits - 1] = temp->digits[temp_idx++];
		if (temp->numberOfDigits == 2)
		{
			carry = temp->digits[1];
		}
		else
		{
			carry = 0;
		}
		temp_idx = 0;
		idx_1 += 1;
		idx_2 += 1;
	}
	if (idx_1 != pNumber1->numberOfDigits)
	{
		while (idx_1 != pNumber1->numberOfDigits)
		{
			temp = newNumberInBase256(pNumber1->digits[idx_1]);
			Database->numberOfDigits++;
			Database->digits[Database->numberOfDigits - 1] = temp->digits[temp_idx++] + carry;
			if (temp->numberOfDigits == 2)
			{
				carry = temp->digits[1];
			}
			else
			{
				carry = 0;
			}
			temp_idx = 0;
			idx_1 += 1;
		}
	}
	if (idx_2 != pNumber2->numberOfDigits)
	{
		while (idx_2 != pNumber2->numberOfDigits)
		{
			temp = newNumberInBase256(pNumber2->digits[idx_2]);
			Database->numberOfDigits++;
			Database->digits[Database->numberOfDigits - 1] = temp->digits[temp_idx++] + carry;
			if (temp->numberOfDigits == 2)
			{
				carry = temp->digits[1];
			}
			else
			{
				carry = 0;
			}
			temp_idx = 0;
			idx_2 += 1;
		}
	}
	if (carry != 0)
	{
		Database->numberOfDigits++;
		Database->digits[Database->numberOfDigits - 1] = carry;
	}
	return Database;
}

//
// Return
//  1 - when pNumber1 > pNumber2
//  0 - otherwise
//
int isGreater(Base256Number *pNumber1, Base256Number *pNumber2) {
	if (pNumber1->numberOfDigits > pNumber2->numberOfDigits)
		return 1;
	else
	{
		int idx = 0;
		if (pNumber1->numberOfDigits == pNumber2->numberOfDigits)
		{
			int value = pNumber1->numberOfDigits;
			while (value--)
			{
				if (pNumber1->digits[value] != pNumber2->digits[value])
				{
					if (pNumber1->digits[value] > pNumber2->digits[value])
						return 1;
					else
						return 0;
				}
			}
		}
		return 0;
	}
}

//
// Return
//  1 - are equal
//  0 - not equal
//
int areEqual_base256(Base256Number *pNumber1, Base256Number *pNumber2) {
	if (pNumber1->numberOfDigits > pNumber2->numberOfDigits)
		return 0;
	if (pNumber1->numberOfDigits <= pNumber2->numberOfDigits)
	{
		int idx = 0;
		while (idx != (pNumber1->numberOfDigits))
		{
			if (pNumber1->digits[idx] != pNumber2->digits[idx])
				return 0;
			idx++;
		}
		return 1;
	}
	return 0;
}

//
// increments the given number by 1
//
// Note: Need to reallocate memory for pNumber->digits when needed
//
void incrementInBase256(Base256Number *pNumber) {
	int idx = 0, loop = 1, carry = 1, max = pNumber->numberOfDigits;
	Base256Number *temp = (Base256Number*)malloc(sizeof(Base256Number));
	while (loop)
	{
		if (idx < max)
		{
			temp = newNumberInBase256(pNumber->digits[idx] + carry);
			pNumber->digits[idx] = temp->digits[0];
		}
		else
		{
			loop = 0;
		}
		idx++;
		if (temp->numberOfDigits == 1)
		{
			loop = 0;
			carry = 0;
		}
		else
		{
			carry = temp->digits[1];
		}
	}
	if (carry == 1){
		++pNumber->numberOfDigits;
		UInt8 *data = (UInt8*)malloc(sizeof(UInt8)*pNumber->numberOfDigits);
		for (int idx = 0; idx < pNumber->numberOfDigits - 2; idx++)
		{
			data[idx] = pNumber->digits[idx];
		}
		data[pNumber->numberOfDigits-1] = carry;
		pNumber->digits = data;
	}
}

//
// you need make the test cases for these last 2 functions
// pass by implementing the above functions
// - multiplyInBase256
// - integerDivisionInBase256
//
//
// DON'T MODIFY THE CODE OF THIS FUNCTION
//
Base256Number *multiplyInBase256(Base256Number *pNumber1, Base256Number *pNumber2) {
	Base256Number* result = newNumberInBase256(0);
	Base256Number* count = newNumberInBase256(1);
	Base256Number *pOne = newNumberInBase256(1);

	while (!isGreater(count, pNumber2)) {
		result = addInBase256(result, pNumber1);
		count = addInBase256(count, pOne);
	}
	return result;
}

//
// integer division
//
//
// DON'T MODIFY THE CODE OF THIS FUNCTION
//
Base256Number *integerDivisionInBase256(Base256Number *pNumber, Base256Number *pDiv) {

	Base256Number *pQuotient = newNumberInBase256(0);
	Base256Number *pTempNumber = newNumberInBase256(0);
	Base256Number *pOne = newNumberInBase256(1);

	if (isGreater(pDiv, pNumber)) {
		return pQuotient;
	}

	pTempNumber = addInBase256(pTempNumber, pDiv);
	while (isGreater(pNumber, pTempNumber)) {
		pQuotient = addInBase256(pQuotient, pOne);
		pTempNumber = addInBase256(pTempNumber, pDiv);
	}

	if (areEqual_base256(pNumber, pTempNumber)) {
		pQuotient = addInBase256(pQuotient, pOne);
	}

	return pQuotient;
}