//
//  E04_Memory.h
//  Unit02_Exercise04_Understanding_Memory
//

#ifndef E04_Memory_h
#define E04_Memory_h

#include <stdlib.h>

struct dynamicList {
    int count;
    int *list;
};
typedef struct dynamicList DynamicList;

#endif /* E04_Memory_h */





