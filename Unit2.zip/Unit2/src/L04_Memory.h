//
//  L04_Memory.h
//  Unit02_Lesson04_Understanding_Memory
//

#ifndef L04_Memory_h
#define L04_Memory_h

#include <stdlib.h>

void makeItNoMystery(char *mystery);
char *makeMystery();
int memoryFirstByte(int n);
int memoryLastByte(int n);
int ohISee();

#endif /* L04_Memory_h */
