//
//  E04_Memory.cpp
//  Unit02_Exercise04_Understanding_Memory
//

#include "E04_Memory.h"
#include < math.h >
//
// Prime factorization
//

// return an array of prime factors
int prime(int num)
{
	for (int idx = 2; idx < sqrt((double)num); idx++)
	{
		if (num%idx == 0)
			return 0;
	}
	return 1;
}
DynamicList *primeFactors(int n) {
	DynamicList * res = (DynamicList *)malloc(sizeof(DynamicList));
	int idx = 2;
	res->count = 0;
	res->list = NULL;
	while (n != 1)
	{
		if (n%idx == 0 && prime(idx))
		{
			res->count++;
			res->list = (int*)realloc(res->list, sizeof(int)*res->count);
			res->list[res->count - 1] = idx;
			n /= idx;
		}
		else
		{
			idx++;
		}
	}
	return res;
}
