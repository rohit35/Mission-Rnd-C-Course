/*
OVERVIEW:  Given a single linked list of 0s 1s and 2s ,Sort the SLL such that zeroes
will be followed by ones and then twos.

You should only change the links and shouldnt swap the data. Basically no write operation should be done on data field.

INPUTS:  SLL head pointer
OUTPUT: Sorted SLL ,Head should Finally point to an sll of sorted 0,1,2
ERROR CASES:
NOTES: Only 0,1,2, will be in sll nodes
*/

#include <stdio.h>
#include <malloc.h>

struct node {
	int data;
	struct node *next;
};
int checking_order(struct node**head)
{
	struct node* cur = *head;
	while (cur && cur->next!=NULL)
	{
		if (cur->data > cur->next->data)
			return 1;
		cur = cur->next;
	}
	return 0;
}
/*
Optional : For this function swapping data is allowed.Although this wont be tested on our end.
It is only for learning purpose.
*/
void sll_012_sort_swapData(struct node **head){

}

/*
This is the actual function. You are supposed to change only the links.
*/
void sll_012_sort(struct node **head){
	if (checking_order(head)){
		struct node * last_ptr = *head;
		int num = 0;
		while (last_ptr->next != NULL)
		{
			last_ptr = last_ptr->next;
			num++;
		}
		num++;
		struct node*tail = last_ptr, *cur_ptr = *head, *pre_ptr = *head;
		while (num--)
		{
			struct node* temp = cur_ptr;
			cur_ptr = cur_ptr->next;
			if (temp->data == 0)
			{
				if (pre_ptr != temp)
				{
					temp->next = *head;
					*head = temp;
					pre_ptr->next = cur_ptr;
				}
			}
			else if (temp->data == 2)
			{
				tail->next = temp;
				temp->next = NULL;
				tail = temp;
				if (pre_ptr == temp)
					*head = pre_ptr = cur_ptr;
				else
					pre_ptr->next = cur_ptr;
			}
			else
			{
				if (pre_ptr != temp)
					pre_ptr = pre_ptr->next;
			}
		}
	}
}


