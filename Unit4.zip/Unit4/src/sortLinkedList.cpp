/*
OVERVIEW: Given an unsorted single linked list, sort the linked list without using extra array or linked list.
E.g.: 4->2->1->5->3, output is 1->2->3->4->5.

INPUTS: An unsorted single linked list.

OUTPUT: Sort the linked list.

ERROR CASES: Return NULL for error cases.

NOTES: Without using extra array or linked list.

*/

#include <stdio.h>
#include <stdlib.h>

struct node {
	int num;
	struct node *next;
};

struct node * sortLinkedList(struct node *head) {
	if (head == NULL)
		return NULL;
	int loop = 1, number;
	struct node*pos;
	pos = head;
	while (loop)
	{
		while (pos->next != NULL)
		{
			if (pos->num > (pos->next)->num)
			{
				number = pos->num;
				pos->num = pos->next->num;
				pos->next->num = number;
			}
			pos = pos->next;
		}
		pos = head;
		if (number == 0)
			loop = 0;
		number = 0;
	}
	return head;
}