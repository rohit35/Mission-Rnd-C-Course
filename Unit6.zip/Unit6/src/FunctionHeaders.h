void test_functionpointers_starter();
void test_voidpointers();
void test_max_subarray();
void test_combine_common_elements();