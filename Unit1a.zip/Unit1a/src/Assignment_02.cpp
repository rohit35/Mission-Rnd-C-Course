
//
// Compute factorial of a given positive integer
// 0 <= n <= 100
//
// return value         - number of digits in n!
// factorialDigits[158] - digits of n!
//
#include<malloc.h>
void initalizing_zero(int factorialDigits[158])
{
	for (int idx = 0; idx < 159; idx++)
		factorialDigits[idx] = 0;
}
int check(int factorialDigits[158])
{
	int limit = 0,count=0;
	for (int idx = 0; idx < 159; idx++)
	{
		if (factorialDigits[idx] != 0)
		{
			limit = idx;
			break;
		}
	}
	while (limit < 159)
	{
		factorialDigits[count++] = factorialDigits[limit];
		factorialDigits[limit] = 0;
		limit++;
	}
	return count;
}
int factorialOfN(int n, int factorialDigits[158]) {
	int *temp_array = (int*)malloc(sizeof(int) * 159);
	initalizing_zero(factorialDigits);
	factorialDigits[158] = 1;
	int Total=0, pos=0,idx_2, temp,limit=0;
	for (int idx = 1; idx <= n; idx++)
	{
		temp = idx;
		initalizing_zero(temp_array);
		limit = 0;
		while (temp != 0)
		{
			pos = 158;
			idx_2 = 158 - limit;
			while (pos >= 0 )
			{
				Total = (factorialDigits[pos] * (temp % 10));
				temp_array[idx_2] += Total;
				pos--;
				idx_2--;
			}
			limit++;
			temp /= 10;
		}
		for (int idx = 0; idx < 159; idx++)
			factorialDigits[idx] = temp_array[idx];
		for (int idx = 158; idx >= 0; idx--)
		{
			if (factorialDigits[idx]>9)
			{
				limit = factorialDigits[idx];
				factorialDigits[idx] = limit % 10;
				factorialDigits[idx - 1] += limit / 10;
			}
		}
	}
	return check(factorialDigits);
}


//
// recamán’s sequence: "subtract if you can, otherwise add"
//
// a(0) = 0; for n > 0, a(n) = a(n-1) - n if positive and
// not already in the sequence, otherwise a(n) = a(n-1) + n.
//
// http://oeis.org/A005132
//
// Write a function to find the first n numbers in this sequence
// n >= 0
//
// e.g:
// 0 => {0}
// 2 => {0, 1, 3}
// 5 => {0, 1, 3, 6, 2, 7}
//
// Note:
// The sequence will contain (n + 1) terms.
//
void recamanSequence(int n, int sequence[]) { 
	sequence[0] = 0;
	for (int idx = 1; idx<=n; idx++)
	{
		int curr = sequence[idx - 1] - idx;
		int pos;
		for (pos = 0; pos < idx; pos++)
		{ 
			if ((sequence[pos] == curr) || curr < 0)
			{
				curr = sequence[idx - 1] + idx;
				break;
			}
		}
		sequence[idx] = curr;
	}
}
