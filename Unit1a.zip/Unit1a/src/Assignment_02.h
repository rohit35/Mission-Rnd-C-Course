//
//  Assignment_02.h
//  Unit1_assignment_02
//

#ifndef Assignment_02_h
#define Assignment_02_h

int factorialOfN(int n, int factorialDigits[158]);
void recamanSequence(int n, int sequence[]);

#endif /* Assignment_02_h */
