//
//  Assignment_01.h
//  Unit1_assignment_01
//

#ifndef Assignment_01_h
#define Assignment_01_h

void butterflyNumber(int n, char butterfly[23]);
int palindromeNumbers(int b, int numbers[]);
void first20PalindromicPrimes(int b, int palindromes[20]);
void closest5EvenNumbers(int n, int evens[5]);
void closest5PalindromeNumbers(int n, int b, int palindromes[5]);

#endif /* Assignment_01_h */
