//
// Every number repeats twice, except one number.
// Write a function that finds the number that does not repeat.
//
// e.g:
// {11, 8, 11}, 3  => 8
//
#include<malloc.h>
int numberWithoutRepeatition(int numbers[], int size) {
	int number = 0,pos=0;
	int *array = (int*)calloc(size,sizeof(int));
	for (int idx = 0; idx < size; idx++)
	{
		if (array[idx] == 0)
		{
			number = numbers[idx];
			pos = idx + 1;
			while (pos < size && pos != -1)
			{
				if (number == numbers[pos])
				{
					array[idx] = -1;
					array[pos] = -1;
					pos = -1;
				}
				else
				{
					pos++;
				}

			}
			if (pos == size)
				return number;
		}
	}
	return number;
}

//
// encode an array of numbers by doing
// XOR with n'th prime number
// and subtract 1
//
// output the encode numbers in encodedMessage[8] array.
//
// e.g:
// for 5'th prime
// encoding will be
// (message[i] ^ 11) - 1
// since 11 is the 5'th prime. // 2, 3, 5, 7, 11...
//
#include<math.h>
int prime(int num)
{
	int count = 0, loop = 0,idx=2;
	while (1)
	{
		loop = 1;
		for (int number = 2; number <= sqrt((double)idx); number++)
		{
			if (idx%number == 0)
			{
				loop = 0;
			}
		}
		if (loop)
		{
			count++;
		}
		if (count == num)
			return idx;
		idx++;
	}
}
void encodeWithNthPrime(int message[8], int n, int encodedMessage[8]) {
	n = prime(n);
	for (int idx = 0; idx < 8; idx++)
	{
		encodedMessage[idx] = (message[idx] ^ n) - 1;
	}
}

//
// decode an array of numbers in
// which are encoded using above encodeWithPrime function.
//
// output the decoded numbers in decodedMessage[8] array.
//
void decodeWithNthPrime(int message[8], int n, int decodedMessage[8]) {
	n = prime(n);
	for (int idx = 0; idx < 8; idx++)
	{
		decodedMessage[idx] = ((message[idx]+1) ^ n);
	}
}
//
// Encode data and flags in packet header
//
// From Left to Right the data and flags are packed as follows:
// fromMobileId   - 7 bits
// toMobileId     - 7 bits
// msgId          - 7 bits
// msgLen         - 7 bits
// reserved       - 2 bits
// urgent         - 1 flag bit
// adHoc          - 1 flag bit
//
// Note:
// The values will be in the range
// 0 <= fromMobileId, toMobileId, msgId, msgLen <= 127
void convert(int *Array, int num, int start, int max)
{
	int count = 0;
	while (count < max && num != 0)
	{
		if (num % 2 == 0)
			Array[start] = 0;
		else
			Array[start] = 1;
		num /= 2;
		start++;
		count++;
	}
	while (count < max)
	{
		Array[start++] = 0;
		count++;
	}	
}
unsigned int packHeader(int fromMobileId, int toMobileId, int msgId,
                        int msgLen, bool urgent, bool adHoc) {
	int *Array = (int*)malloc(sizeof(int) * 32);
	Array[0] = adHoc;
	Array[1] = urgent;
	Array[2] = 0;
	Array[3] = 0;
	convert(Array, msgLen, 4, 7);
	convert(Array, msgId, 11, 7);
	convert(Array, toMobileId, 18, 7);
	convert(Array, fromMobileId, 25, 7);
	unsigned int Total = 0;
	for (int idx = 0; idx < 32; idx++)
	{
		if (Array[idx] == 1)
		{
			Total += (1 << idx);
		}
	}
	return Total;
}

// unpack a given header, with the properties like the above

void deconvert(int *Array, int *MsgLen, int start, int max)
{
	int Total = 0;
	for (int idx = 0, pos = start; idx < max; idx++, pos++)
	{
		if (Array[pos] == 1)
		{
			Total += (1 << idx);
		}
	}
	int *poin = &Total;
	*MsgLen = *poin;
}
void unpackHeader(unsigned int header, int *pFromMobileId, int *pToMobileId,
                  int *pMsgId, int *pMsgLen, bool *pUrgent, bool *pAdHoc) {
	int *Array = (int*)malloc(sizeof(int) * 32);
	for (int idx = 0; idx < 32; idx++)
	{
		if (header % 2 == 0)
			Array[idx] = 0;
		else
			Array[idx] = 1;
		header /= 2;
	}
	bool pad, pur;
	pad = Array[0] ? true : false;
	pur = Array[1] ? true : false;
	bool *var = &pad;
	*pAdHoc = *var;
	var = &pur;
	*pUrgent = *var;
	deconvert(Array, pMsgLen, 4,7);
	deconvert(Array, pMsgId, 11, 7);
	deconvert(Array, pToMobileId, 18, 7);
	deconvert(Array, pFromMobileId, 25, 7);
}