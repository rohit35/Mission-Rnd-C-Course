#ifndef TestHelperMethods_h
#define TestHelperMethods_h

bool areEqualArrays(int a[], int b[], int size);
bool areEqualStrings(char a[], char b[]);

#endif /* TestHelperMethods_h */
