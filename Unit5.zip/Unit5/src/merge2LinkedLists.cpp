/*
OVERVIEW: Merge two sorted linked lists.
E.g.: 1->3->5 and 2->4, output is 1->2->3->4->5.

INPUTS: Two sorted linked lists.

OUTPUT: Return merged sorted linked list.

ERROR CASES: Return NULL for error cases.

NOTES:
*/
#include <stdio.h>

struct node {
	int num;
	struct node *next;
};
int counting(struct node *data)
{
	int count = 0;
	while (data != NULL)
	{
		count++;
		data = data->next;
	}
	return count;
}
int same(struct node*head1, struct node* head2)
{
	while (head1 != NULL && head2 != NULL)
	{
		if (head1->num != head2->num)
		{
			return 0;
		}
		head1 = head1->next;
		head2 = head2->next;
	}
	if (head1 == NULL && head2 == NULL)
		return 1;
	return 0;
}

struct node * merge2LinkedLists(struct node *head1, struct node *head2) {
	if (head1 == NULL && head2 == NULL)
		return NULL;
	if (head1 == NULL && head2 != NULL)
		return head2;
	if (head1 != NULL && head2 == NULL)
		return head1;
	int len_1 = counting(head1), len_2 = counting(head2);
	struct node *temp = NULL, *head = NULL, *first = head1, *second = head2, *prev = NULL;
	while (len_1 != 0 && len_2 != 0)
	{
		if (first->num > second->num)
		{
			if (temp == NULL)
			{
				temp = second;
				head = temp;
			}
			else
			{
				temp->next = second;
				temp = temp->next;
			}
			len_2--;
			second = second->next;
		}
		else if (first->num < second->num)
		{
			len_1--;
			if (temp == NULL)
			{
				temp = first;
				head = temp;
			}
			else
			{
				temp->next = first;
				temp = temp->next;
			}
			first = first->next;
		}
		else
		{
			if (temp == NULL)
			{
				temp = first;
				head = temp;
				first = first->next;
				temp->next = second;
				second = second->next;
				temp = temp->next;
			}
			else
			{
				temp->next = first;
				temp = temp->next;
				first = first->next;
				temp->next = second;
				second = second->next;
				temp = temp->next;
			}
			len_1--;
			len_2--;
		}
	}
	if (len_1 != 0)
	{
		while (first != NULL)
		{
			temp->next = first;
			temp = temp->next;
			first = first->next;
		}
	}
	if (len_2 != 0)
	{
		while (second != NULL)
		{
			temp->next = second;
			temp = temp->next;
			second = second->next;
		}
	}
	return head;
}
