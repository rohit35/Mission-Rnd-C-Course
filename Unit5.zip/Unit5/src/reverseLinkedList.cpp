/*
OVERVIEW: Given a single linked list, reverse the linked list.
E.g.: 1->2->3->4->5, output is 5->4->3->2->1.

INPUTS: A linked list.

OUTPUT: Reverse the linked list.

ERROR CASES: Return NULL for error cases.

NOTES:
*/

#include <stdio.h>
#include<malloc.h>
struct node {
	int num;
	struct node *next;
};

struct node * reverseLinkedList(struct node *head) {
	if (head == NULL)
		return NULL;
	struct node *temp = head;
	int *max_array = NULL;
	int idx = 0;
	while (temp != NULL)
	{
		idx++;
		max_array = (int*)realloc(max_array, sizeof(struct node)*idx);
		max_array[idx - 1] = temp->num;
		temp = temp->next;
	}
	temp = NULL;
	while (idx--)
	{
		struct node*cur = (struct node*)malloc(sizeof(struct node));
		cur->num = max_array[idx];
		cur->next = NULL;
		if (temp == NULL)
		{
			temp = cur;
			head = temp;
		}
		else
		{
			temp->next = cur;
			temp = temp->next;
		}
	}
	return head;
}
