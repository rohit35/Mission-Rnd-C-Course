struct node * insertAtEveryKthNode(struct node *, int);
int linkedListMedian(struct node *);
struct node * merge2LinkedLists(struct node *, struct node *);
struct node * reverseLinkedList(struct node *);
int * oddeven_sll(struct oddevennode *head);
int merge_circularlists(struct node **head1, struct node **head2);
int between_days(struct node *date1head, struct node *date2head);
int doorstoCross(struct passKeyNode *passKeyHead);
void pairUp(struct ListNode *head);