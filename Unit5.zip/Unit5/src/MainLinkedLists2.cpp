/*

Use MainLinkedLists2 File for testing any other function in other Cpp files of the Strings Project.

DO NOT write main function in any other File or else your Build Fails.

Objectives of LinkedLists2 Lesson:

->Merging two Linked Lists
->Reversing a LinkedList
->Inserting at a specific index

*/
#include <stdio.h>
#include "FunctionHeadersLinkedLists2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ListNode{
	int val;
	struct ListNode *next;
};

struct ListNode *createNode_P6(int val){
	struct ListNode *newNode = (struct ListNode *)malloc(sizeof(struct ListNode));
	newNode->next = NULL;
	newNode->val = val;
	return newNode;
}

struct ListNode* createList_P6(char *s){
	int i;
	struct ListNode *walker = NULL;
	struct ListNode *head = createNode_P6(s[0]);
	walker = head;
	for (i = 1; s[i] != '\0'; i++){
		walker->next = createNode_P6(s[i]);
		walker = walker->next;
	}

	return head;
}

void createDataAndTest_P6(char *input, char *expectedOutput) {
	struct ListNode * head = createList_P6(input);
	pairUp(head);

	char actualStr[510] = "";
	int i = 0;

	while (head){
		actualStr[i] = (head->val);
		head = head->next;
		i++;
	}


}

int main(){

	//Test InsertAtEveryKthNode

	//Test LinkedListMedian

	//Test merge2 LinkedLists
	createDataAndTest_P6("912354786", "961827345");
	//Test reverse LinkedList
}