/*
Q4: Two dates are given in a 8 node single linked list form,where each node
has one digit only, dates 01-31, months 01-12, year 0000-9999.

Find the number of days in between those two dates .[Exclusive]

Ex : Date1:  0->1->0->1->2->0->0->4 .
     Date2 : 0->5->0->1->2->0->0->4 should return 3 .
As there are 3 days between Jan1st 2004 and Jan 5th 2004.

Ex 2 : Date1 : 3->1->1->2->2->0->1->2.
       Date2 : 0->2->0->1->2->0->1->3 should return 1 .
(There is only one day between 31st Dec 2012 and 2nd  Jan 2013 .)

Note : Consecutive Days and Same Days should return 0;
->Return -1 for NULL Inputs .
->Between Days have to be calculated by not including start and end date .
->The SLL will have 8 Nodes in all cases . Year 999 will be represented as 0999.

Difficulty : Hard 
*/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

struct node{
	int data;
	struct node *next;
};

void collect_data(struct node*Database, int *day, int *month, int* year)
{
	int data = 0, limit = 2;
	while (limit--)
	{
		data = data * 10 + Database->data;
		Database = Database->next;
	}
	*day = data;
	limit = 2;
	data = 0;
	while (limit--)
	{
		data = data * 10 + Database->data;
		Database = Database->next;
	}
	limit = 4;
	*month = data;
	data = 0;
	while (limit--)
	{
		data = data * 10 + Database->data;
		Database = Database->next;
	}
	*year = data;
}
int check_leapyear(int year)
{
	if (year % 4 == 0)
	{
		if (year % 100 == 0)
		{
			// year is divisible by 400, hence the year is a leap year
			if (year % 400 == 0)
				return 1;
			else
				return 0;
		}
		else
			return 1;
	}
	else
		return 0;
}
int counting_dates(int date, int month, int year, int total_months)
{
	int month_dates[2][13] = { { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
	{ 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 } };
	int count = 0, year_check = check_leapyear(year);
	while (month < total_months)
	{
		count += month_dates[year_check][month] - date;
		date = 0;
		month += 1;
	}
	return count;
}
int between_days(struct node *date1head, struct node *date2head){
	if (date1head == NULL || date2head == NULL)
		return -1;
	int total = 0;
	int date_1 = 0, month_1 = 0, year_1 = 0, date_2 = 0, month_2 = 0, year_2 = 0;
	collect_data(date1head, &date_1, &month_1, &year_1);
	collect_data(date2head, &date_2, &month_2, &year_2);
	if (year_1 != year_2)
	{
		if (year_1 < year_2)
		{
			while (year_1 < year_2){
				total += counting_dates(date_1, month_1, year_1, 13);
				date_1 = 0;
				year_1++;
				month_1 = 1;
			}
			if (month_1 < month_2)
			{
				total += counting_dates(date_1, month_1, year_1, month_2);
			}
			total += date_2 - 1;
		}
		else
		{
			while (year_2 < year_1){
				total += counting_dates(date_2, month_2, year_2, 13);
				date_2 = 0;
				year_2++;
				month_2 = 1;
			}
			if (month_2 < month_1)
			{
				total += counting_dates(date_2, month_2, year_2, month_1);
			}
			total += date_1 - 1;
		}
		return total;
	}
	else
	{
		if (month_1 < month_2)
		{
			total += counting_dates(date_1, month_1, year_1, month_2);
			total += date_2 - 1;
		}
		else if (month_2 < month_1)
		{
			total += counting_dates(date_2, month_2, year_2, month_1);
			total += date_1 - 1;
		}
		else
		{
			if (date_1 == date_2)
			{
				return 0;
			}
			else
			{
				if (date_2 > date_1){
					total = date_2 - date_1 - 1;
				}
				else
				{
					total = date_1 - date_2 - 1;
				}
			}
		}
		return total;
	}
	return 0;
}