/*
OVERVIEW: Write a function to find sum of two integers.
E.g.: sum(2, 3) returns 5.

INPUTS: Two integers number1 and number2.

OUTPUT: Sum of the integers number1 and number2.
*/

int sum(int number1, int number2)
{
	return (number1+number2);
}
